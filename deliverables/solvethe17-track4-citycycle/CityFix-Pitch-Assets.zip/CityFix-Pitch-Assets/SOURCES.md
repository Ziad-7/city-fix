# Asset sources
- screens/mobile-*.png, web-*.png, admin-*.png: rendered from the team's CityFix-design-html.zip (HTML designs), 2x, design-hub label bar hidden.
- screens/simulator.png: real capture of the PC simulator in hardware/simulator (local mock, port 8765).
- brand/*.svg: repo docs/design/assets.
- qr/citizen-web-qr.svg: generated for https://city-fix-trojans.vercel.app (regenerate if the link changes).
- Fonts: Readex Pro, IBM Plex Sans Arabic, Aref Ruqaa (Google Fonts).
Not available yet: real screenshots of CityCycle request, collector mode, Command Center bins/route screens, a physical bin.
